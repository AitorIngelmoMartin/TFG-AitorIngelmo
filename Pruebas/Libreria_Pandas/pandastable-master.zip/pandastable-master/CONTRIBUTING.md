# How to contribute

## Developers

Any programmers interested in contributing are welcome. Have a look through the code to judge any weaknesses or
if it's amenable to easy changes. There are currently deficencies in error checking and exception handling 
for example which have not yet been addressed due to time.

## End users

Contributions from educators who might want to use this software are sought. This could come in the form of testing and
requesting new features.
